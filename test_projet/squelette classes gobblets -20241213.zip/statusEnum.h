#ifndef STATUSENUM_H
#define STATUSENUM_H

enum StatusEnum{
    OK,
    INVALID_SOURCE,
    INVALID_TARGET,
    INVALID_ENTRY
};

#endif // STATUSENUM_H
